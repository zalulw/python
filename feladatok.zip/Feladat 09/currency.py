EUR: float = 400
JPY: float = 0.75 * EUR
USD: float = 0.8 * EUR
CHF: float = 0.55 * EUR